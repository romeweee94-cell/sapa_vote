/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          red: "#D7263D",
          redDark: "#9E1B2D",
          yellow: "#FFC93C",
          yellowDark: "#F2A104",
          cream: "#FFF8E7"
        }
      },
      backgroundImage: {
        "brand-gradient": "linear-gradient(135deg, #FFC93C 0%, #FFA13C 35%, #D7263D 100%)",
        "brand-gradient-soft": "linear-gradient(135deg, #FFF3D6 0%, #FFE1C2 100%)"
      },
      boxShadow: {
        glow: "0 0 25px rgba(255, 201, 60, 0.55)",
        card: "0 10px 30px rgba(157, 27, 45, 0.15)"
      },
      keyframes: {
        floatUp: {
          "0%": { transform: "translateY(10px)", opacity: 0 },
          "100%": { transform: "translateY(0)", opacity: 1 }
        },
        pulseGlow: {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(215,38,61,0.45)" },
          "50%": { boxShadow: "0 0 0 12px rgba(215,38,61,0)" }
        }
      },
      animation: {
        floatUp: "floatUp .5s ease-out",
        pulseGlow: "pulseGlow 2s infinite"
      }
    }
  },
  plugins: []
};
