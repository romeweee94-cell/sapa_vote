"use client";

export default function Error({
  reset
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-gradient-soft px-4">
      <div className="card p-10 text-center max-w-sm">
        <div className="text-6xl mb-4">⚠️</div>
        <h1 className="text-2xl font-extrabold text-brand-redDark mb-2">
          เกิดข้อผิดพลาด
        </h1>
        <p className="text-brand-redDark/60 mb-6">
          ระบบขัดข้องชั่วคราว กรุณาลองใหม่อีกครั้ง
        </p>
        <button onClick={() => reset()} className="btn-primary">
          ลองใหม่
        </button>
      </div>
    </div>
  );
}
