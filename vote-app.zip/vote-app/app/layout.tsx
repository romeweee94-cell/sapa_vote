import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Prompt } from "next/font/google";
import "./globals.css";

const prompt = Prompt({
  subsets: ["thai", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-prompt"
});

export const metadata: Metadata = {
  title: "ระบบโหวตออนไลน์",
  description: "โหวตรูปภาพที่คุณชื่นชอบ ระบบโหวตออนไลน์ยุคใหม่"
};

export default function RootLayout({
  children
}: {
  children: ReactNode;
}) {
  return (
    <html lang="th" className={prompt.variable}>
      <body className="font-sans min-h-screen">{children}</body>
    </html>
  );
}
