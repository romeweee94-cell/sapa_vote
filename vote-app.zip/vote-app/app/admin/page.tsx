"use client";

import { useEffect, useState, useCallback, FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";

type Candidate = {
  id: number;
  name: string;
  description: string;
  image_url: string;
  vote_count: number;
  created_at: string;
};

type AppUser = {
  id: number;
  username: string;
  device_id: string;
  created_at: string;
  voted_for: string | null;
  voted_candidate_id: number | null;
};

type Voter = {
  id: number;
  username: string;
  candidate_name: string;
  created_at: string;
};

type LogRow = {
  id: number;
  action: string;
  detail: string;
  created_at: string;
};

const TABS = [
  { key: "candidates", label: "🖼️ รูปโหวต" },
  { key: "schedule", label: "⏰ ตั้งเวลาโหวต" },
  { key: "users", label: "👥 ผู้สมัคร" },
  { key: "votes", label: "📊 ผลโหวต" },
  { key: "logs", label: "🧾 บันทึกระบบ" }
] as const;

type TabKey = (typeof TABS)[number]["key"];

function toDatetimeLocal(iso: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`;
}

export default function AdminPage() {
  const [checking, setChecking] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);
  const [tab, setTab] = useState<TabKey>("candidates");
  const [toast, setToast] = useState<string | null>(null);

  const checkAuth = useCallback(async () => {
    setChecking(true);
    const res = await fetch("/api/admin/me");
    const data = await res.json();
    setLoggedIn(!!data.loggedIn);
    setChecking(false);
  }, []);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2200);
    return () => clearTimeout(t);
  }, [toast]);

  async function login(e: FormEvent) {
    e.preventDefault();
    setLoginError("");
    setLoginLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password })
      });
      const data = await res.json();
      if (!res.ok) {
        setLoginError(data.error || "เข้าสู่ระบบไม่สำเร็จ");
        return;
      }
      setLoggedIn(true);
      setPassword("");
    } catch {
      setLoginError("เชื่อมต่อเซิร์ฟเวอร์ไม่ได้");
    } finally {
      setLoginLoading(false);
    }
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    setLoggedIn(false);
  }

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-gradient-soft">
        <p className="text-brand-redDark/60">กำลังตรวจสอบสิทธิ์...</p>
      </div>
    );
  }

  if (!loggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-gradient-soft px-4">
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={login}
          className="card w-full max-w-sm p-8"
        >
          <div className="text-center mb-6">
            <div className="w-14 h-14 rounded-full bg-brand-gradient shadow-glow mx-auto mb-3" />
            <h1 className="font-bold text-xl text-brand-redDark">เข้าสู่ระบบผู้ดูแล</h1>
          </div>
          <input
            type="password"
            className="input-field"
            placeholder="รหัสผ่านผู้ดูแลระบบ"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoFocus
          />
          {loginError && (
            <p className="text-sm text-brand-red font-medium mt-3">{loginError}</p>
          )}
          <button disabled={loginLoading} className="btn-primary w-full mt-5">
            {loginLoading ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
          </button>
          <a
            href="/"
            className="block text-center text-sm text-brand-redDark/50 underline mt-4"
          >
            กลับหน้าหลัก
          </a>
        </motion.form>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-gradient-soft">
      <header className="sticky top-0 z-30 backdrop-blur bg-white/80 border-b border-brand-yellow/50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-brand-gradient" />
            <span className="font-bold text-brand-redDark">แผงควบคุมผู้ดูแลระบบ</span>
          </div>
          <div className="flex items-center gap-2">
            <a href="/" className="btn-secondary !px-4 !py-2 text-sm">
              หน้าหลัก
            </a>
            <button onClick={logout} className="btn-primary !px-4 !py-2 text-sm">
              ออกจากระบบ
            </button>
          </div>
        </div>
        <div className="max-w-6xl mx-auto px-4 pb-2 flex gap-2 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-semibold transition ${
                tab === t.key
                  ? "bg-brand-gradient text-white shadow-glow"
                  : "bg-brand-cream text-brand-redDark"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {tab === "candidates" && <CandidatesTab setToast={setToast} />}
        {tab === "schedule" && <ScheduleTab setToast={setToast} />}
        {tab === "users" && <UsersTab setToast={setToast} />}
        {tab === "votes" && <VotesTab />}
        {tab === "logs" && <LogsTab />}
      </main>

      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-brand-redDark text-white px-5 py-3 rounded-full shadow-lg text-sm font-medium"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function CandidatesTab({ setToast }: { setToast: (s: string) => void }) {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<Candidate | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/admin/candidates");
    const data = await res.json();
    setCandidates(data.candidates || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    if (!file) {
      setError("กรุณาเลือกไฟล์รูปภาพ");
      return;
    }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("name", name);
      fd.append("description", description);
      fd.append("image", file);
      const res = await fetch("/api/admin/candidates", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "อัปโหลดไม่สำเร็จ");
        return;
      }
      setName("");
      setDescription("");
      setFile(null);
      (document.getElementById("candidate-file") as HTMLInputElement).value = "";
      setToast("เพิ่มรูปสำเร็จ");
      await load();
    } catch {
      setError("เชื่อมต่อเซิร์ฟเวอร์ไม่ได้");
    } finally {
      setUploading(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    await fetch("/api/admin/candidates", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: deleteTarget.id })
    });
    setToast("ลบรูปแล้ว");
    setDeleteTarget(null);
    await load();
  }

  return (
    <div className="grid md:grid-cols-3 gap-6">
      <form onSubmit={submit} className="card p-6 h-fit md:col-span-1">
        <h2 className="font-bold text-lg text-brand-redDark mb-4">เพิ่มรูปใหม่</h2>
        <div className="flex flex-col gap-3">
          <input
            className="input-field"
            placeholder="ชื่อรูป / ผู้เข้าแข่งขัน"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <textarea
            className="input-field"
            placeholder="คำอธิบาย (ไม่บังคับ)"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
          />
          <input
            id="candidate-file"
            type="file"
            accept="image/*"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="text-sm"
            required
          />
          {error && <p className="text-sm text-brand-red font-medium">{error}</p>}
          <button disabled={uploading} className="btn-primary mt-2">
            {uploading ? "กำลังอัปโหลด..." : "เพิ่มรูป"}
          </button>
        </div>
      </form>

      <div className="md:col-span-2">
        {loading ? (
          <p className="text-brand-redDark/60">กำลังโหลด...</p>
        ) : candidates.length === 0 ? (
          <p className="text-brand-redDark/60">ยังไม่มีรูปในระบบ</p>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {candidates.map((c) => (
              <div key={c.id} className="card overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={c.image_url} alt={c.name} className="w-full h-40 object-cover" />
                <div className="p-4">
                  <h3 className="font-bold text-brand-redDark">{c.name}</h3>
                  <p className="text-sm text-brand-redDark/60 mt-1">
                    {c.description || "—"}
                  </p>
                  <p className="text-sm mt-2 font-semibold text-brand-red">
                    โหวตแล้ว {c.vote_count} เสียง
                  </p>
                  <button
                    onClick={() => setDeleteTarget(c)}
                    className="btn-secondary w-full mt-3 text-sm !py-2"
                  >
                    ลบรูปนี้
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <AnimatePresence>
        {deleteTarget && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setDeleteTarget(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="card w-full max-w-sm p-6 text-center"
            >
              <h3 className="font-bold text-lg text-brand-redDark">
                ลบรูป "{deleteTarget.name}" ?
              </h3>
              <p className="text-sm text-brand-redDark/60 mt-1">
                คะแนนโหวตของรูปนี้จะถูกลบไปด้วย และไม่สามารถกู้คืนได้
              </p>
              <div className="flex gap-3 mt-5">
                <button
                  onClick={() => setDeleteTarget(null)}
                  className="btn-secondary flex-1"
                >
                  ยกเลิก
                </button>
                <button onClick={confirmDelete} className="btn-primary flex-1">
                  ยืนยันลบ
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ScheduleTab({ setToast }: { setToast: (s: string) => void }) {
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/admin/settings");
      const data = await res.json();
      setStart(toDatetimeLocal(data.vote_start));
      setEnd(toDatetimeLocal(data.vote_end));
      setLoading(false);
    })();
  }, []);

  async function save(e: FormEvent) {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          voteStart: new Date(start).toISOString(),
          voteEnd: new Date(end).toISOString()
        })
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "บันทึกไม่สำเร็จ");
        return;
      }
      setToast("บันทึกเวลาการโหวตแล้ว");
    } catch {
      setError("เชื่อมต่อเซิร์ฟเวอร์ไม่ได้");
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <p className="text-brand-redDark/60">กำลังโหลด...</p>;

  return (
    <form onSubmit={save} className="card p-6 max-w-md">
      <h2 className="font-bold text-lg text-brand-redDark mb-4">ตั้งเวลาเปิด-ปิดโหวต</h2>
      <div className="flex flex-col gap-4">
        <label className="text-sm font-semibold text-brand-redDark">
          เวลาเปิดโหวต
          <input
            type="datetime-local"
            className="input-field mt-1"
            value={start}
            onChange={(e) => setStart(e.target.value)}
            required
          />
        </label>
        <label className="text-sm font-semibold text-brand-redDark">
          เวลาปิดโหวต
          <input
            type="datetime-local"
            className="input-field mt-1"
            value={end}
            onChange={(e) => setEnd(e.target.value)}
            required
          />
        </label>
        {error && <p className="text-sm text-brand-red font-medium">{error}</p>}
        <button disabled={saving} className="btn-primary mt-2">
          {saving ? "กำลังบันทึก..." : "บันทึกเวลา"}
        </button>
      </div>
    </form>
  );
}

function UsersTab({ setToast }: { setToast: (s: string) => void }) {
  const [users, setUsers] = useState<AppUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState<AppUser | null>(null);
  const [search, setSearch] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/admin/users");
    const data = await res.json();
    setUsers(data.users || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function confirmDelete() {
    if (!deleteTarget) return;
    await fetch("/api/admin/users", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: deleteTarget.id })
    });
    setToast("ลบผู้ใช้แล้ว");
    setDeleteTarget(null);
    await load();
  }

  const filtered = users.filter((u) =>
    u.username.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
        <h2 className="font-bold text-lg text-brand-redDark">
          รายชื่อผู้สมัคร ({users.length} คน)
        </h2>
        <input
          className="input-field !w-56"
          placeholder="ค้นหาชื่อผู้ใช้..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      {loading ? (
        <p className="text-brand-redDark/60">กำลังโหลด...</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-brand-redDark/60 border-b border-brand-yellow/40">
                <th className="py-2 pr-4">ชื่อผู้ใช้</th>
                <th className="py-2 pr-4">รหัสอุปกรณ์</th>
                <th className="py-2 pr-4">โหวตให้</th>
                <th className="py-2 pr-4">สมัครเมื่อ</th>
                <th className="py-2 pr-4">จัดการ</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u.id} className="border-b border-brand-yellow/20">
                  <td className="py-2 pr-4 font-semibold text-brand-redDark">
                    {u.username}
                  </td>
                  <td className="py-2 pr-4 text-brand-redDark/50 font-mono text-xs">
                    {u.device_id.slice(0, 8)}...
                  </td>
                  <td className="py-2 pr-4">
                    {u.voted_for ? (
                      <span className="text-brand-red font-semibold">{u.voted_for}</span>
                    ) : (
                      <span className="text-brand-redDark/40">ยังไม่โหวต</span>
                    )}
                  </td>
                  <td className="py-2 pr-4 text-brand-redDark/60">
                    {new Date(u.created_at).toLocaleString("th-TH")}
                  </td>
                  <td className="py-2 pr-4">
                    <button
                      onClick={() => setDeleteTarget(u)}
                      className="text-brand-red font-semibold hover:underline"
                    >
                      ลบ
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <p className="text-center text-brand-redDark/50 py-6">ไม่พบข้อมูล</p>
          )}
        </div>
      )}

      <AnimatePresence>
        {deleteTarget && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setDeleteTarget(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="card w-full max-w-sm p-6 text-center"
            >
              <h3 className="font-bold text-lg text-brand-redDark">
                ลบผู้ใช้ "{deleteTarget.username}" ?
              </h3>
              <p className="text-sm text-brand-redDark/60 mt-1">
                ผู้ใช้จะสามารถสมัครใหม่ได้จากอุปกรณ์เดิมอีกครั้ง
              </p>
              <div className="flex gap-3 mt-5">
                <button
                  onClick={() => setDeleteTarget(null)}
                  className="btn-secondary flex-1"
                >
                  ยกเลิก
                </button>
                <button onClick={confirmDelete} className="btn-primary flex-1">
                  ยืนยันลบ
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function VotesTab() {
  const [tally, setTally] = useState<Candidate[]>([]);
  const [voters, setVoters] = useState<Voter[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/admin/votes");
      const data = await res.json();
      setTally(data.tally || []);
      setVoters(data.voters || []);
      setLoading(false);
    })();
  }, []);

  if (loading) return <p className="text-brand-redDark/60">กำลังโหลด...</p>;

  const totalVotes = tally.reduce((sum, c) => sum + (c.vote_count || 0), 0);

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="card p-6">
        <h2 className="font-bold text-lg text-brand-redDark mb-4">
          คะแนนรวม ({totalVotes} เสียง)
        </h2>
        <div className="flex flex-col gap-3">
          {tally.map((c) => {
            const pct = totalVotes ? Math.round((c.vote_count / totalVotes) * 100) : 0;
            return (
              <div key={c.id}>
                <div className="flex justify-between text-sm font-semibold text-brand-redDark mb-1">
                  <span>{c.name}</span>
                  <span>
                    {c.vote_count} เสียง ({pct}%)
                  </span>
                </div>
                <div className="h-3 rounded-full bg-brand-cream overflow-hidden">
                  <div
                    className="h-full bg-brand-gradient transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
          {tally.length === 0 && (
            <p className="text-brand-redDark/50">ยังไม่มีรูปในระบบ</p>
          )}
        </div>
      </div>

      <div className="card p-6">
        <h2 className="font-bold text-lg text-brand-redDark mb-4">
          รายชื่อผู้โหวต ({voters.length})
        </h2>
        <div className="overflow-x-auto max-h-96 overflow-y-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-brand-redDark/60 border-b border-brand-yellow/40">
                <th className="py-2 pr-4">ผู้ใช้</th>
                <th className="py-2 pr-4">โหวตให้</th>
                <th className="py-2 pr-4">เวลา</th>
              </tr>
            </thead>
            <tbody>
              {voters.map((v) => (
                <tr key={v.id} className="border-b border-brand-yellow/20">
                  <td className="py-2 pr-4 font-semibold text-brand-redDark">
                    {v.username}
                  </td>
                  <td className="py-2 pr-4 text-brand-red font-semibold">
                    {v.candidate_name}
                  </td>
                  <td className="py-2 pr-4 text-brand-redDark/60">
                    {new Date(v.created_at).toLocaleString("th-TH")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {voters.length === 0 && (
            <p className="text-center text-brand-redDark/50 py-6">ยังไม่มีผู้โหวต</p>
          )}
        </div>
      </div>
    </div>
  );
}

function LogsTab() {
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/admin/logs");
      const data = await res.json();
      setLogs(data.logs || []);
      setLoading(false);
    })();
  }, []);

  if (loading) return <p className="text-brand-redDark/60">กำลังโหลด...</p>;

  return (
    <div className="card p-6">
      <h2 className="font-bold text-lg text-brand-redDark mb-4">บันทึกการทำงานของระบบ</h2>
      <div className="overflow-x-auto max-h-[32rem] overflow-y-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-brand-redDark/60 border-b border-brand-yellow/40">
              <th className="py-2 pr-4">การกระทำ</th>
              <th className="py-2 pr-4">รายละเอียด</th>
              <th className="py-2 pr-4">เวลา</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l.id} className="border-b border-brand-yellow/20">
                <td className="py-2 pr-4 font-semibold text-brand-redDark">{l.action}</td>
                <td className="py-2 pr-4 text-brand-redDark/70">{l.detail}</td>
                <td className="py-2 pr-4 text-brand-redDark/60">
                  {new Date(l.created_at).toLocaleString("th-TH")}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {logs.length === 0 && (
          <p className="text-center text-brand-redDark/50 py-6">ยังไม่มีบันทึก</p>
        )}
      </div>
    </div>
  );
}
