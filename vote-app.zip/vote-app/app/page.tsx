"use client";

import { useEffect, useState, useCallback, FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";

type Candidate = {
  id: number;
  name: string;
  description: string;
  image_url: string;
  vote_count?: number;
};

type Settings = {
  voteStart: string | null;
  voteEnd: string | null;
  status: "not_configured" | "upcoming" | "open" | "closed";
};

type Me = {
  loggedIn: boolean;
  username?: string;
  votedCandidateId?: number | null;
};

function useCountdown(target: string | null) {
  const [remaining, setRemaining] = useState<number>(0);
  useEffect(() => {
    if (!target) return;
    const tick = () => {
      const diff = new Date(target).getTime() - Date.now();
      setRemaining(diff > 0 ? diff : 0);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [target]);
  return remaining;
}

function formatDuration(ms: number) {
  const totalSec = Math.floor(ms / 1000);
  const d = Math.floor(totalSec / 86400);
  const h = Math.floor((totalSec % 86400) / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const parts = [];
  if (d > 0) parts.push(`${d} วัน`);
  parts.push(`${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(
    s
  ).padStart(2, "0")}`);
  return parts.join(" ");
}

export default function HomePage() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [me, setMe] = useState<Me>({ loggedIn: false });
  const [loading, setLoading] = useState(true);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("register");
  const [authForm, setAuthForm] = useState({ username: "", password: "" });
  const [authError, setAuthError] = useState("");
  const [authLoading, setAuthLoading] = useState(false);
  const [confirmCandidate, setConfirmCandidate] = useState<Candidate | null>(null);
  const [voteError, setVoteError] = useState("");
  const [voteLoading, setVoteLoading] = useState(false);
  const [successOpen, setSuccessOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const countdownTarget =
    settings?.status === "upcoming"
      ? settings.voteStart
      : settings?.status === "open"
      ? settings.voteEnd
      : null;
  const remaining = useCountdown(countdownTarget);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [cRes, sRes, mRes] = await Promise.all([
        fetch("/api/candidates"),
        fetch("/api/settings"),
        fetch("/api/me")
      ]);
      const [cData, sData, mData] = await Promise.all([
        cRes.json(),
        sRes.json(),
        mRes.json()
      ]);
      setCandidates(cData.candidates || []);
      setSettings(sData);
      setMe(mData);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetch("/api/device").catch(() => {});
    loadAll();
  }, [loadAll]);

  useEffect(() => {
    if (
      (settings?.status === "upcoming" || settings?.status === "open") &&
      remaining === 0
    ) {
      const t = setTimeout(() => loadAll(), 1200);
      return () => clearTimeout(t);
    }
  }, [remaining, settings?.status, loadAll]);

  async function submitAuth(e: FormEvent) {
    e.preventDefault();
    setAuthError("");
    setAuthLoading(true);
    try {
      const res = await fetch(`/api/${authMode === "login" ? "login" : "register"}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(authForm)
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || "เกิดข้อผิดพลาด");
        return;
      }
      setAuthOpen(false);
      setAuthForm({ username: "", password: "" });
      setToast(authMode === "login" ? "เข้าสู่ระบบสำเร็จ" : "สมัครสมาชิกสำเร็จ");
      await loadAll();
    } catch {
      setAuthError("เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ กรุณาลองใหม่");
    } finally {
      setAuthLoading(false);
    }
  }

  async function logout() {
    await fetch("/api/logout", { method: "POST" });
    setToast("ออกจากระบบแล้ว");
    await loadAll();
  }

  async function confirmVote() {
    if (!confirmCandidate) return;
    setVoteError("");
    setVoteLoading(true);
    try {
      const res = await fetch("/api/vote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ candidateId: confirmCandidate.id })
      });
      const data = await res.json();
      if (!res.ok) {
        setVoteError(data.error || "โหวตไม่สำเร็จ");
        return;
      }
      setConfirmCandidate(null);
      setSuccessOpen(true);
      await loadAll();
    } catch {
      setVoteError("เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ กรุณาลองใหม่");
    } finally {
      setVoteLoading(false);
    }
  }

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2500);
    return () => clearTimeout(t);
  }, [toast]);

  const votingOpen = settings?.status === "open";

  return (
    <main className="min-h-screen bg-brand-gradient-soft">
      {/* Top bar */}
      <header className="sticky top-0 z-30 backdrop-blur bg-white/70 border-b border-brand-yellow/50">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-brand-gradient shadow-glow" />
            <span className="font-bold text-lg text-brand-redDark">ระบบโหวตออนไลน์</span>
          </div>
          {me.loggedIn ? (
            <div className="flex items-center gap-3">
              <span className="text-sm text-brand-redDark hidden sm:block">
                สวัสดี, <b>{me.username}</b>
              </span>
              <button onClick={logout} className="btn-secondary !px-4 !py-2 text-sm">
                ออกจากระบบ
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setAuthMode("login");
                  setAuthOpen(true);
                }}
                className="btn-secondary !px-4 !py-2 text-sm"
              >
                เข้าสู่ระบบ
              </button>
              <button
                onClick={() => {
                  setAuthMode("register");
                  setAuthOpen(true);
                }}
                className="btn-primary !px-4 !py-2 text-sm"
              >
                สมัครสมาชิก
              </button>
            </div>
          )}
        </div>
      </header>

      <section className="max-w-5xl mx-auto px-4 pt-8 pb-4 text-center">
        <motion.h1
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl sm:text-4xl font-extrabold text-brand-redDark drop-shadow-sm"
        >
          🗳️ โหวตรูปที่คุณชื่นชอบ
        </motion.h1>
        <p className="text-brand-redDark/70 mt-2">
          1 บัญชีต่อ 1 อุปกรณ์ • โหวตได้เพียง 1 รูปเท่านั้น
        </p>

        {/* Status banner */}
        {settings && settings.status !== "open" && (
          <div className="mt-5 inline-flex flex-col items-center gap-1 card px-6 py-4">
            {settings.status === "not_configured" && (
              <p className="font-semibold text-brand-redDark">
                ยังไม่มีการเปิดรอบโหวตในขณะนี้
              </p>
            )}
            {settings.status === "upcoming" && (
              <>
                <p className="font-semibold text-brand-redDark">การโหวตจะเปิดในอีก</p>
                <p className="text-2xl font-mono font-bold text-brand-red">
                  {formatDuration(remaining)}
                </p>
              </>
            )}
            {settings.status === "closed" && (
              <p className="font-semibold text-brand-redDark">ปิดรับโหวตแล้ว ขอบคุณที่เข้าร่วม 🙏</p>
            )}
          </div>
        )}
        {settings?.status === "open" && (
          <div className="mt-5 inline-flex flex-col items-center gap-1 card px-6 py-4 animate-pulseGlow">
            <p className="font-semibold text-brand-red">🔥 เปิดโหวตอยู่ ปิดรับใน</p>
            <p className="text-2xl font-mono font-bold text-brand-red">
              {formatDuration(remaining)}
            </p>
          </div>
        )}

        {me.loggedIn && me.votedCandidateId && (
          <div className="mt-4 text-brand-redDark font-medium">
            ✅ คุณได้โหวตให้{" "}
            <b>{candidates.find((c) => c.id === me.votedCandidateId)?.name}</b> แล้ว
          </div>
        )}
      </section>

      {/* Candidates grid */}
      <section className="max-w-5xl mx-auto px-4 pb-16">
        {loading ? (
          <div className="text-center py-20 text-brand-redDark/60">กำลังโหลด...</div>
        ) : candidates.length === 0 ? (
          <div className="text-center py-20 text-brand-redDark/60">
            ยังไม่มีรูปให้โหวตในขณะนี้
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {candidates.map((c, i) => {
              const isVotedForThis = me.votedCandidateId === c.id;
              return (
                <motion.div
                  key={c.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={`card overflow-hidden flex flex-col ${
                    isVotedForThis ? "ring-4 ring-brand-red" : ""
                  }`}
                >
                  <div className="relative aspect-square bg-brand-yellow/10">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={c.image_url}
                      alt={c.name}
                      className="w-full h-full object-cover"
                    />
                    {isVotedForThis && (
                      <div className="absolute top-3 right-3 bg-brand-red text-white text-xs font-bold px-3 py-1 rounded-full shadow">
                        โหวตแล้ว
                      </div>
                    )}
                  </div>
                  <div className="p-4 flex flex-col gap-3 flex-1">
                    <div>
                      <h3 className="font-bold text-lg text-brand-redDark">{c.name}</h3>
                      {c.description && (
                        <p className="text-sm text-brand-redDark/60 mt-1">
                          {c.description}
                        </p>
                      )}
                    </div>
                    <div className="mt-auto">
                      <button
                        disabled={!votingOpen || !!me.votedCandidateId || !me.loggedIn}
                        onClick={() => {
                          if (!me.loggedIn) {
                            setAuthMode("register");
                            setAuthOpen(true);
                            return;
                          }
                          setConfirmCandidate(c);
                        }}
                        className="btn-primary w-full"
                      >
                        {isVotedForThis
                          ? "คุณโหวตรูปนี้"
                          : me.votedCandidateId
                          ? "โหวตแล้ว"
                          : !votingOpen
                          ? "ยังไม่เปิดโหวต"
                          : "โหวตรูปนี้"}
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </section>

      <footer className="text-center text-sm text-brand-redDark/50 pb-8">
        © {new Date().getFullYear()} ระบบโหวตออนไลน์ •{" "}
        <a href="/admin" className="underline hover:text-brand-red">
          สำหรับผู้ดูแลระบบ
        </a>
      </footer>

      {/* Auth modal */}
      <AnimatePresence>
        {authOpen && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setAuthOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="card w-full max-w-sm p-6"
            >
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setAuthMode("register")}
                  className={`flex-1 py-2 rounded-full font-semibold text-sm transition ${
                    authMode === "register"
                      ? "bg-brand-gradient text-white shadow-glow"
                      : "bg-brand-cream text-brand-redDark"
                  }`}
                >
                  สมัครสมาชิก
                </button>
                <button
                  onClick={() => setAuthMode("login")}
                  className={`flex-1 py-2 rounded-full font-semibold text-sm transition ${
                    authMode === "login"
                      ? "bg-brand-gradient text-white shadow-glow"
                      : "bg-brand-cream text-brand-redDark"
                  }`}
                >
                  เข้าสู่ระบบ
                </button>
              </div>
              <form onSubmit={submitAuth} className="flex flex-col gap-3">
                <input
                  className="input-field"
                  placeholder="ชื่อผู้ใช้"
                  value={authForm.username}
                  onChange={(e) =>
                    setAuthForm((f) => ({ ...f, username: e.target.value }))
                  }
                  required
                  minLength={3}
                />
                <input
                  className="input-field"
                  placeholder="รหัสผ่าน"
                  type="password"
                  value={authForm.password}
                  onChange={(e) =>
                    setAuthForm((f) => ({ ...f, password: e.target.value }))
                  }
                  required
                  minLength={4}
                />
                {authMode === "register" && (
                  <p className="text-xs text-brand-redDark/50">
                    * สมัครได้ 1 บัญชีต่อ 1 อุปกรณ์เท่านั้น
                  </p>
                )}
                {authError && (
                  <p className="text-sm text-brand-red font-medium">{authError}</p>
                )}
                <button disabled={authLoading} className="btn-primary mt-2">
                  {authLoading
                    ? "กำลังดำเนินการ..."
                    : authMode === "login"
                    ? "เข้าสู่ระบบ"
                    : "สมัครสมาชิก"}
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirm vote modal */}
      <AnimatePresence>
        {confirmCandidate && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => !voteLoading && setConfirmCandidate(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="card w-full max-w-sm p-6 text-center"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={confirmCandidate.image_url}
                alt={confirmCandidate.name}
                className="w-28 h-28 object-cover rounded-2xl mx-auto shadow-card"
              />
              <h3 className="font-bold text-xl mt-4 text-brand-redDark">
                ยืนยันโหวตให้ "{confirmCandidate.name}" ?
              </h3>
              <p className="text-sm text-brand-redDark/60 mt-1">
                เมื่อยืนยันแล้วจะไม่สามารถเปลี่ยนแปลงได้
              </p>
              {voteError && (
                <p className="text-sm text-brand-red font-medium mt-3">{voteError}</p>
              )}
              <div className="flex gap-3 mt-5">
                <button
                  disabled={voteLoading}
                  onClick={() => setConfirmCandidate(null)}
                  className="btn-secondary flex-1"
                >
                  ยกเลิก
                </button>
                <button
                  disabled={voteLoading}
                  onClick={confirmVote}
                  className="btn-primary flex-1"
                >
                  {voteLoading ? "กำลังโหวต..." : "ยืนยัน"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success modal */}
      <AnimatePresence>
        {successOpen && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSuccessOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.7, opacity: 0, rotate: -5 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              exit={{ scale: 0.7, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="card w-full max-w-sm p-8 text-center"
            >
              <div className="text-6xl mb-3">🎉</div>
              <h3 className="font-bold text-2xl text-brand-redDark">โหวตสำเร็จ!</h3>
              <p className="text-brand-redDark/60 mt-1">ขอบคุณที่ร่วมโหวตกับเรา</p>
              <button
                onClick={() => setSuccessOpen(false)}
                className="btn-primary mt-6 w-full"
              >
                ปิด
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-brand-redDark text-white px-5 py-3 rounded-full shadow-lg text-sm font-medium"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
