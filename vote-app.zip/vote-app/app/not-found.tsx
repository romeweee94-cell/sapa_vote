export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-gradient-soft px-4">
      <div className="card p-10 text-center max-w-sm">
        <div className="text-6xl mb-4">🔎</div>
        <h1 className="text-2xl font-extrabold text-brand-redDark mb-2">
          ไม่พบหน้านี้
        </h1>
        <p className="text-brand-redDark/60 mb-6">
          หน้าที่คุณต้องการอาจถูกย้ายหรือไม่มีอยู่จริง
        </p>
        <a href="/" className="btn-primary inline-flex">
          กลับหน้าหลัก
        </a>
      </div>
    </div>
  );
}
