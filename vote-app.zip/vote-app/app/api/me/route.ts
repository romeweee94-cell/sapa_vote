import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { getUserSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  await ensureSchema();
  const session = getUserSession(req);
  if (!session) {
    return NextResponse.json({ loggedIn: false });
  }

  const voteRes = await sql`
    SELECT candidate_id FROM votes WHERE user_id = ${session.userId} LIMIT 1;
  `;

  return NextResponse.json({
    loggedIn: true,
    username: session.username,
    votedCandidateId: voteRes.rows[0]?.candidate_id ?? null
  });
}
