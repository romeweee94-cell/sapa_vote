import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { sql, ensureSchema } from "@/lib/db";
import { setUserCookie } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    await ensureSchema();
    const { username, password } = await req.json();
    if (!username || !password) {
      return NextResponse.json(
        { error: "กรุณากรอกชื่อผู้ใช้และรหัสผ่าน" },
        { status: 400 }
      );
    }

    const result = await sql`
      SELECT id, username, password_hash FROM app_users WHERE username = ${username} LIMIT 1;
    `;
    const user = result.rows[0];
    if (!user) {
      return NextResponse.json(
        { error: "ไม่พบชื่อผู้ใช้นี้ในระบบ" },
        { status: 401 }
      );
    }

    const valid = await bcrypt.compare(String(password), user.password_hash);
    if (!valid) {
      return NextResponse.json({ error: "รหัสผ่านไม่ถูกต้อง" }, { status: 401 });
    }

    const res = NextResponse.json({
      ok: true,
      user: { id: user.id, username: user.username }
    });
    setUserCookie(res, { userId: user.id, username: user.username });
    return res;
  } catch (err) {
    console.error("login error", err);
    return NextResponse.json(
      { error: "เกิดข้อผิดพลาดในระบบ กรุณาลองใหม่อีกครั้ง" },
      { status: 500 }
    );
  }
}
