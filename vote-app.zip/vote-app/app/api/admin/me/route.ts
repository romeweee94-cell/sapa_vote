import { NextRequest, NextResponse } from "next/server";
import { getAdminSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const session = getAdminSession(req);
  return NextResponse.json({ loggedIn: !!session });
}
