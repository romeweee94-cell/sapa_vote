import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema, logAdminAction } from "@/lib/db";
import { getAdminSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  await ensureSchema();
  if (!getAdminSession(req)) {
    return NextResponse.json({ error: "ไม่มีสิทธิ์เข้าถึง" }, { status: 401 });
  }
  const result = await sql`SELECT vote_start, vote_end FROM settings WHERE id = 1;`;
  return NextResponse.json(result.rows[0] || { vote_start: null, vote_end: null });
}

export async function PUT(req: NextRequest) {
  await ensureSchema();
  if (!getAdminSession(req)) {
    return NextResponse.json({ error: "ไม่มีสิทธิ์เข้าถึง" }, { status: 401 });
  }
  const { voteStart, voteEnd } = await req.json();
  if (!voteStart || !voteEnd) {
    return NextResponse.json(
      { error: "กรุณาระบุเวลาเปิดและปิดโหวตให้ครบ" },
      { status: 400 }
    );
  }
  if (new Date(voteEnd) <= new Date(voteStart)) {
    return NextResponse.json(
      { error: "เวลาปิดโหวตต้องอยู่หลังเวลาเปิดโหวต" },
      { status: 400 }
    );
  }

  await sql`
    UPDATE settings SET vote_start = ${voteStart}, vote_end = ${voteEnd} WHERE id = 1;
  `;
  await logAdminAction(
    "update_settings",
    `ตั้งเวลาโหวต: ${voteStart} ถึง ${voteEnd}`
  );
  return NextResponse.json({ ok: true });
}
