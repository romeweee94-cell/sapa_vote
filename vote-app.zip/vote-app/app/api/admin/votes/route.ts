import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { getAdminSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  await ensureSchema();
  if (!getAdminSession(req)) {
    return NextResponse.json({ error: "ไม่มีสิทธิ์เข้าถึง" }, { status: 401 });
  }

  const tally = await sql`
    SELECT c.id, c.name, c.image_url,
      (SELECT COUNT(*) FROM votes v WHERE v.candidate_id = c.id)::int AS vote_count
    FROM candidates c
    ORDER BY vote_count DESC;
  `;

  const voters = await sql`
    SELECT v.id, u.username, c.name AS candidate_name, v.created_at
    FROM votes v
    JOIN app_users u ON u.id = v.user_id
    JOIN candidates c ON c.id = v.candidate_id
    ORDER BY v.created_at DESC;
  `;

  return NextResponse.json({ tally: tally.rows, voters: voters.rows });
}
