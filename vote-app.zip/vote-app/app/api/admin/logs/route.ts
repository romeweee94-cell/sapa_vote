import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { getAdminSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  await ensureSchema();
  if (!getAdminSession(req)) {
    return NextResponse.json({ error: "ไม่มีสิทธิ์เข้าถึง" }, { status: 401 });
  }
  const result = await sql`
    SELECT id, action, detail, created_at FROM admin_logs
    ORDER BY created_at DESC LIMIT 200;
  `;
  return NextResponse.json({ logs: result.rows });
}
