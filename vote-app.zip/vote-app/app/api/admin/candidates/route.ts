import { NextRequest, NextResponse } from "next/server";
import { put, del } from "@vercel/blob";
import { sql, ensureSchema, logAdminAction } from "@/lib/db";
import { getAdminSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  await ensureSchema();
  if (!getAdminSession(req)) {
    return NextResponse.json({ error: "ไม่มีสิทธิ์เข้าถึง" }, { status: 401 });
  }
  const result = await sql`
    SELECT c.id, c.name, c.description, c.image_url, c.created_at,
      (SELECT COUNT(*) FROM votes v WHERE v.candidate_id = c.id)::int AS vote_count
    FROM candidates c
    ORDER BY c.id ASC;
  `;
  return NextResponse.json({ candidates: result.rows });
}

export async function POST(req: NextRequest) {
  await ensureSchema();
  if (!getAdminSession(req)) {
    return NextResponse.json({ error: "ไม่มีสิทธิ์เข้าถึง" }, { status: 401 });
  }

  try {
    const formData = await req.formData();
    const name = String(formData.get("name") || "").trim();
    const description = String(formData.get("description") || "").trim();
    const file = formData.get("image") as File | null;

    if (!name) {
      return NextResponse.json({ error: "กรุณาระบุชื่อรูป/ผู้เข้าแข่งขัน" }, { status: 400 });
    }
    if (!file || typeof file === "string") {
      return NextResponse.json({ error: "กรุณาแนบไฟล์รูปภาพ" }, { status: 400 });
    }
    if (!process.env.BLOB_READ_WRITE_TOKEN) {
      return NextResponse.json(
        { error: "ยังไม่ได้ตั้งค่า Vercel Blob storage (BLOB_READ_WRITE_TOKEN)" },
        { status: 500 }
      );
    }

    const filename = `candidates/${Date.now()}-${file.name.replace(/\s+/g, "-")}`;
    const blob = await put(filename, file, {
      access: "public",
      addRandomSuffix: true
    });

    const inserted = await sql`
      INSERT INTO candidates (name, description, image_url)
      VALUES (${name}, ${description}, ${blob.url})
      RETURNING id, name, description, image_url, created_at;
    `;

    await logAdminAction("add_candidate", `เพิ่มรูป: ${name}`);
    return NextResponse.json({ ok: true, candidate: inserted.rows[0] });
  } catch (err) {
    console.error("add candidate error", err);
    return NextResponse.json(
      { error: "เกิดข้อผิดพลาดในการอัปโหลด กรุณาลองใหม่อีกครั้ง" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  await ensureSchema();
  if (!getAdminSession(req)) {
    return NextResponse.json({ error: "ไม่มีสิทธิ์เข้าถึง" }, { status: 401 });
  }
  const { id } = await req.json();
  if (!id) {
    return NextResponse.json({ error: "ไม่พบรหัสรูป" }, { status: 400 });
  }

  const existing = await sql`SELECT name, image_url FROM candidates WHERE id = ${id};`;
  if (!existing.rowCount) {
    return NextResponse.json({ error: "ไม่พบรูปนี้" }, { status: 404 });
  }

  await sql`DELETE FROM candidates WHERE id = ${id};`;

  try {
    if (existing.rows[0].image_url && process.env.BLOB_READ_WRITE_TOKEN) {
      await del(existing.rows[0].image_url);
    }
  } catch (e) {
    console.warn("blob delete failed (non-fatal)", e);
  }

  await logAdminAction("delete_candidate", `ลบรูป: ${existing.rows[0].name}`);
  return NextResponse.json({ ok: true });
}
