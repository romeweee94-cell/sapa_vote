import { NextResponse } from "next/server";
import { clearAdminCookie } from "@/lib/auth";
import { logAdminAction } from "@/lib/db";

export async function POST() {
  const res = NextResponse.json({ ok: true });
  clearAdminCookie(res);
  await logAdminAction("logout", "แอดมินออกจากระบบ");
  return res;
}
