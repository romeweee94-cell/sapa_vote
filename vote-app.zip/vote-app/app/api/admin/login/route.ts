import { NextRequest, NextResponse } from "next/server";
import { ensureSchema, logAdminAction } from "@/lib/db";
import { setAdminCookie } from "@/lib/auth";

export async function POST(req: NextRequest) {
  await ensureSchema();
  const { password } = await req.json();
  // Default password works out of the box. To change it, set an
  // ADMIN_PASSWORD environment variable in your Vercel project settings.
  const adminPassword = process.env.ADMIN_PASSWORD || "PhaiZa080800272870";

  if (password !== adminPassword) {
    await logAdminAction("failed_login", "รหัสผ่านผิด");
    return NextResponse.json({ error: "รหัสผ่านไม่ถูกต้อง" }, { status: 401 });
  }

  const res = NextResponse.json({ ok: true });
  setAdminCookie(res);
  await logAdminAction("login", "แอดมินเข้าสู่ระบบสำเร็จ");
  return res;
}
