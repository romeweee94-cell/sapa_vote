import { NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";

export async function GET() {
  await ensureSchema();
  const result = await sql`
    SELECT c.id, c.name, c.description, c.image_url,
      (SELECT COUNT(*) FROM votes v WHERE v.candidate_id = c.id)::int AS vote_count
    FROM candidates c
    ORDER BY c.id ASC;
  `;
  return NextResponse.json({ candidates: result.rows });
}
