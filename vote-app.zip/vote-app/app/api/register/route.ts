import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { sql, ensureSchema } from "@/lib/db";
import { getOrCreateDeviceId } from "@/lib/device";
import { setUserCookie } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    await ensureSchema();
    const { username, password } = await req.json();

    if (!username || !password || String(username).trim().length < 3) {
      return NextResponse.json(
        { error: "กรุณากรอกชื่อผู้ใช้ (อย่างน้อย 3 ตัวอักษร) และรหัสผ่าน" },
        { status: 400 }
      );
    }
    if (String(password).length < 4) {
      return NextResponse.json(
        { error: "รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร" },
        { status: 400 }
      );
    }

    const res = NextResponse.json({ ok: true });
    const deviceId = getOrCreateDeviceId(req, res);

    const deviceCheck = await sql`
      SELECT id FROM app_users WHERE device_id = ${deviceId} LIMIT 1;
    `;
    if (deviceCheck.rowCount && deviceCheck.rowCount > 0) {
      return NextResponse.json(
        { error: "อุปกรณ์นี้เคยสมัครสมาชิกไปแล้ว (1 อุปกรณ์ต่อ 1 บัญชี)" },
        { status: 409 }
      );
    }

    const existingUser = await sql`
      SELECT id FROM app_users WHERE username = ${username} LIMIT 1;
    `;
    if (existingUser.rowCount && existingUser.rowCount > 0) {
      return NextResponse.json(
        { error: "ชื่อผู้ใช้นี้ถูกใช้ไปแล้ว กรุณาเลือกชื่ออื่น" },
        { status: 409 }
      );
    }

    const passwordHash = await bcrypt.hash(String(password), 10);

    const inserted = await sql`
      INSERT INTO app_users (username, password_hash, device_id)
      VALUES (${username}, ${passwordHash}, ${deviceId})
      RETURNING id, username;
    `;
    const user = inserted.rows[0];

    setUserCookie(res, { userId: user.id, username: user.username });
    return res;
  } catch (err: any) {
    console.error("register error", err);
    return NextResponse.json(
      { error: "เกิดข้อผิดพลาดในระบบ กรุณาลองใหม่อีกครั้ง" },
      { status: 500 }
    );
  }
}
