import { NextRequest, NextResponse } from "next/server";
import { getOrCreateDeviceId } from "@/lib/device";

export async function GET(req: NextRequest) {
  const existing = req.cookies.get("device_id")?.value;
  const res = NextResponse.json({ ok: true, deviceId: existing ?? "pending" });
  const deviceId = getOrCreateDeviceId(req, res);
  if (!existing) {
    // rewrite body now that we know the freshly generated id
    return NextResponse.json({ ok: true, deviceId }, { headers: res.headers });
  }
  return res;
}
