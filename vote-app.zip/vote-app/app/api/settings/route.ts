import { NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";

export async function GET() {
  await ensureSchema();
  const result = await sql`SELECT vote_start, vote_end FROM settings WHERE id = 1;`;
  const row = result.rows[0] || { vote_start: null, vote_end: null };

  const now = new Date();
  const start = row.vote_start ? new Date(row.vote_start) : null;
  const end = row.vote_end ? new Date(row.vote_end) : null;

  let status: "not_configured" | "upcoming" | "open" | "closed" = "not_configured";
  if (start && end) {
    if (now < start) status = "upcoming";
    else if (now >= start && now <= end) status = "open";
    else status = "closed";
  }

  return NextResponse.json({
    voteStart: row.vote_start,
    voteEnd: row.vote_end,
    status
  });
}
