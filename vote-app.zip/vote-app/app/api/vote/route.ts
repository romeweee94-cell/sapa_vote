import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { getUserSession } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    await ensureSchema();
    const session = getUserSession(req);
    if (!session) {
      return NextResponse.json(
        { error: "กรุณาเข้าสู่ระบบก่อนโหวต" },
        { status: 401 }
      );
    }

    const { candidateId } = await req.json();
    if (!candidateId) {
      return NextResponse.json({ error: "ไม่พบรูปที่เลือก" }, { status: 400 });
    }

    const settingsRes = await sql`SELECT vote_start, vote_end FROM settings WHERE id = 1;`;
    const s = settingsRes.rows[0];
    const now = new Date();
    if (!s?.vote_start || !s?.vote_end) {
      return NextResponse.json(
        { error: "ยังไม่ได้เปิดช่วงเวลาโหวต" },
        { status: 403 }
      );
    }
    if (now < new Date(s.vote_start)) {
      return NextResponse.json({ error: "ยังไม่ถึงเวลาเปิดโหวต" }, { status: 403 });
    }
    if (now > new Date(s.vote_end)) {
      return NextResponse.json({ error: "หมดเวลาโหวตแล้ว" }, { status: 403 });
    }

    const existingVote = await sql`
      SELECT id FROM votes WHERE user_id = ${session.userId} LIMIT 1;
    `;
    if (existingVote.rowCount && existingVote.rowCount > 0) {
      return NextResponse.json(
        { error: "คุณโหวตไปแล้ว โหวตได้เพียงครั้งเดียวเท่านั้น" },
        { status: 409 }
      );
    }

    const candidateRes = await sql`
      SELECT id FROM candidates WHERE id = ${candidateId} LIMIT 1;
    `;
    if (!candidateRes.rowCount) {
      return NextResponse.json({ error: "ไม่พบรูปที่เลือก" }, { status: 404 });
    }

    await sql`
      INSERT INTO votes (user_id, candidate_id) VALUES (${session.userId}, ${candidateId});
    `;

    return NextResponse.json({ ok: true });
  } catch (err: any) {
    if (String(err?.message).includes("duplicate key")) {
      return NextResponse.json(
        { error: "คุณโหวตไปแล้ว โหวตได้เพียงครั้งเดียวเท่านั้น" },
        { status: 409 }
      );
    }
    console.error("vote error", err);
    return NextResponse.json(
      { error: "เกิดข้อผิดพลาดในระบบ กรุณาลองใหม่อีกครั้ง" },
      { status: 500 }
    );
  }
}
